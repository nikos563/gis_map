var wms_layers = [];

var format_clip_ypogeia_ydatika_0 = new ol.format.GeoJSON();
var features_clip_ypogeia_ydatika_0 = format_clip_ypogeia_ydatika_0.readFeatures(json_clip_ypogeia_ydatika_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_clip_ypogeia_ydatika_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_clip_ypogeia_ydatika_0.addFeatures(features_clip_ypogeia_ydatika_0);
var lyr_clip_ypogeia_ydatika_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_clip_ypogeia_ydatika_0, 
                style: style_clip_ypogeia_ydatika_0,
                popuplayertitle: "clip_ypogeia_ydatika",
                interactive: false,
                title: '<img src="styles/legend/clip_ypogeia_ydatika_0.png" /> clip_ypogeia_ydatika'
            });

        var lyr_OpenStreetMap_1 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });

        var lyr_google_satellite_2 = new ol.layer.Tile({
            'title': 'google_satellite',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}'
            })
        });
var format_area_of_interest_3 = new ol.format.GeoJSON();
var features_area_of_interest_3 = format_area_of_interest_3.readFeatures(json_area_of_interest_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_area_of_interest_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_area_of_interest_3.addFeatures(features_area_of_interest_3);
var lyr_area_of_interest_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_area_of_interest_3, 
                style: style_area_of_interest_3,
                popuplayertitle: "area_of_interest",
                interactive: false,
                title: '<img src="styles/legend/area_of_interest_3.png" /> area_of_interest'
            });
var format_odiko2100_buffer50_4 = new ol.format.GeoJSON();
var features_odiko2100_buffer50_4 = format_odiko2100_buffer50_4.readFeatures(json_odiko2100_buffer50_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_odiko2100_buffer50_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_odiko2100_buffer50_4.addFeatures(features_odiko2100_buffer50_4);
var lyr_odiko2100_buffer50_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_odiko2100_buffer50_4, 
                style: style_odiko2100_buffer50_4,
                popuplayertitle: "odiko2100_buffer50",
                interactive: false,
                title: '<img src="styles/legend/odiko2100_buffer50_4.png" /> odiko2100_buffer50'
            });
var format_diff_odiko_ypogeia_natura_arxaiologikoi_5 = new ol.format.GeoJSON();
var features_diff_odiko_ypogeia_natura_arxaiologikoi_5 = format_diff_odiko_ypogeia_natura_arxaiologikoi_5.readFeatures(json_diff_odiko_ypogeia_natura_arxaiologikoi_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_diff_odiko_ypogeia_natura_arxaiologikoi_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_diff_odiko_ypogeia_natura_arxaiologikoi_5.addFeatures(features_diff_odiko_ypogeia_natura_arxaiologikoi_5);
var lyr_diff_odiko_ypogeia_natura_arxaiologikoi_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_diff_odiko_ypogeia_natura_arxaiologikoi_5, 
                style: style_diff_odiko_ypogeia_natura_arxaiologikoi_5,
                popuplayertitle: "diff_odiko_ypogeia_natura_arxaiologikoi",
                interactive: false,
                title: '<img src="styles/legend/diff_odiko_ypogeia_natura_arxaiologikoi_5.png" /> diff_odiko_ypogeia_natura_arxaiologikoi'
            });
var format_drills_in_area_of_interest_6 = new ol.format.GeoJSON();
var features_drills_in_area_of_interest_6 = format_drills_in_area_of_interest_6.readFeatures(json_drills_in_area_of_interest_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_drills_in_area_of_interest_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_drills_in_area_of_interest_6.addFeatures(features_drills_in_area_of_interest_6);
var lyr_drills_in_area_of_interest_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_drills_in_area_of_interest_6, 
                style: style_drills_in_area_of_interest_6,
                popuplayertitle: "drills_in_area_of_interest",
                interactive: false,
                title: '<img src="styles/legend/drills_in_area_of_interest_6.png" /> drills_in_area_of_interest'
            });
var format_diff_od_yp_nat_arx_spit_7 = new ol.format.GeoJSON();
var features_diff_od_yp_nat_arx_spit_7 = format_diff_od_yp_nat_arx_spit_7.readFeatures(json_diff_od_yp_nat_arx_spit_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_diff_od_yp_nat_arx_spit_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_diff_od_yp_nat_arx_spit_7.addFeatures(features_diff_od_yp_nat_arx_spit_7);
var lyr_diff_od_yp_nat_arx_spit_7 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_diff_od_yp_nat_arx_spit_7, 
                style: style_diff_od_yp_nat_arx_spit_7,
                popuplayertitle: "diff_od_yp_nat_arx_spit",
                interactive: false,
                title: '<img src="styles/legend/diff_od_yp_nat_arx_spit_7.png" /> diff_od_yp_nat_arx_spit'
            });
var format_spitia_points_8 = new ol.format.GeoJSON();
var features_spitia_points_8 = format_spitia_points_8.readFeatures(json_spitia_points_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_spitia_points_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_spitia_points_8.addFeatures(features_spitia_points_8);
var lyr_spitia_points_8 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_spitia_points_8, 
                style: style_spitia_points_8,
                popuplayertitle: "spitia_points",
                interactive: false,
                title: '<img src="styles/legend/spitia_points_8.png" /> spitia_points'
            });
var group_group2 = new ol.layer.Group({
                                layers: [lyr_OpenStreetMap_1,lyr_google_satellite_2,lyr_area_of_interest_3,lyr_odiko2100_buffer50_4,lyr_diff_odiko_ypogeia_natura_arxaiologikoi_5,lyr_drills_in_area_of_interest_6,lyr_diff_od_yp_nat_arx_spit_7,lyr_spitia_points_8,],
                                fold: "open",
                                title: "group2"});
var group_clip = new ol.layer.Group({
                                layers: [lyr_clip_ypogeia_ydatika_0,],
                                fold: "open",
                                title: "clip"});

lyr_clip_ypogeia_ydatika_0.setVisible(true);lyr_OpenStreetMap_1.setVisible(true);lyr_google_satellite_2.setVisible(true);lyr_area_of_interest_3.setVisible(true);lyr_odiko2100_buffer50_4.setVisible(true);lyr_diff_odiko_ypogeia_natura_arxaiologikoi_5.setVisible(true);lyr_drills_in_area_of_interest_6.setVisible(true);lyr_diff_od_yp_nat_arx_spit_7.setVisible(true);lyr_spitia_points_8.setVisible(true);
var layersList = [group_clip,group_group2];
lyr_clip_ypogeia_ydatika_0.set('fieldAliases', {'fid': 'fid', 'id': 'id', 'wb_code': 'wb_code', 'wb_name_el': 'wb_name_el', 'quant_stat': 'quant_stat', 'chem_stat': 'chem_stat', 'rbd': 'rbd', 'area_ypogeiwn': 'area_ypogeiwn', });
lyr_area_of_interest_3.set('fieldAliases', {'id': 'id', });
lyr_odiko2100_buffer50_4.set('fieldAliases', {'fid': 'fid', 'objectid': 'objectid', 'type': 'type', 'namegrk': 'namegrk', 'nameeng': 'nameeng', 'length': 'length', 'armodiot': 'armodiot', 'arth_num': 'arth_num', 'other_name': 'other_name', 'οΏ½οΏ½οΏ½': 'οΏ½οΏ½οΏ½', });
lyr_diff_odiko_ypogeia_natura_arxaiologikoi_5.set('fieldAliases', {'fid': 'fid', 'id': 'id', 'wb_code': 'wb_code', 'wb_name_el': 'wb_name_el', 'quant_stat': 'quant_stat', 'chem_stat': 'chem_stat', 'rbd': 'rbd', 'area_ypogeiwn': 'area_ypogeiwn', });
lyr_drills_in_area_of_interest_6.set('fieldAliases', {'fid': 'fid', 'OBJECTID': 'OBJECTID', 'KWDIKOS_SY': 'Αύξων αριθμός', 'X_EGSA87': 'Συντεταγμένη Χ', 'Y_EGSA87': 'Συντεταγμένη Υ', 'Z': 'Ζ', 'IDIOKTHSIAKO_KATHESTWS': 'Καθεστώς ιδιοκτησίας', 'KATHESTWS_XRHSHS': 'Καθεστώς χρήσης', 'EIDOS_SY': 'Είδος Σ.Υ.', 'BATHOS_GEWTRHSHS': 'Βάθος γεώτρησης/πηγαδιού', 'STATHMI_HREMIAS': 'Στάθμη ηρεμίας (σε m)', 'DIAMETROS_DIATRHSHS': 'Διάμετρος γεώτρησης', 'DIAMETROS_SWLHNWSHS': 'Διάμετρος σωλήνωσης', 'HLEKTRODOTHSH': 'Ύπαρξη ηλεκτροδότησης', 'AR_PAROXHS_DEH': 'Αριθμός παροχής ΔΕΗ', 'PIEZOMETRO': 'Παρουσία πιεζόμετρου', 'YDROMETRO': 'Παρουσία υδρομέτρου', 'YDROMETRO_ENDEIKSH': 'Ένδειξη υδρομέτρου', 'YDROMETRO_HMEROMHNIA': 'Ημερομηνία υδρομέτρου', 'ANTLIA': 'Ύπαρξη αντλίας', 'ANTLIA_TYPOS': 'Τύπος αντλίας', 'ANTLIA_IPPODYNAMH': 'Ιπποδύναμη αντλίας σε hp', 'ANTLIA_BATHOS_TOPOTHETHSHS': 'Βάθος τοποθέτησης αντλίας (σε m)', 'AGWGOI_METAFORAS_NEROU': 'Ύπαρξη αγωγών μεταφοράς νερού', 'AGWGOI_METAFORAS_NEROU_ARITHMOS': 'Αριθμός αγωγών μεταφοράς νερού', 'AGWGOI_METAFORAS_NEROU_MHKOS': 'Μήκος αγωγών μεταφοράς νερού', 'PERIFEREIA': 'Περιφέρεια', 'PERIFEREIAKH_ENOTHTA': 'Περιφερειακή ενότητα', 'DHMOS_KALLIKRATH': 'Δήμος (Καλλικράτη)', 'DHMOTIKH_ENOTHTA': 'Δημοτική Ενότητα', 'KOINOTHTA': 'Δημοτική/Τοπική Κοινότητα', 'TOPWNYMIO': 'Τοπωνύμιο', 'YDATIKO_DIAMERISMA': 'Υδατικό διαμέρισμα', 'LEKANH_APORROHS': 'Λεκάνη απορροής', 'YDATIKO_SYSTHMA': 'Υδατικό σύστημα', 'LITHOLOGIA': 'Λιθολογία', 'PARATHRHSEIS': 'Σχόλια - Παρατηρήσεις', 'KWDIKOS_IGME': 'Κωδικός ΙΓΜΕ', 'KWDIKOS_EMSY': 'Κωδικός ΕΜΣΥ', 'created_user': 'created_user', 'created_date': 'created_date', 'last_edited_user': 'last_edited_user', 'last_edited_date': 'last_edited_date', 'KWDIKOS_OPEKEPE': 'Κωδικός ΟΠΕΚΕΠΕ', 'KWDIKOS_EDPYY': 'Κωδικός ΕΔΠΥΥ', 'EIDOS_YDROFOROU': 'Είδος υδροφόρου', 'MESH_PAROXH': 'Παροχή αντλίας σε m3/ώρα', 'DIEYTHINSH_YDATWN': 'Διεύθυνση Υδάτων', 'STATUS': 'Καθεστώς επεξεργασίας', 'IS_INSIDE': 'IS_INSIDE', 'DNSI_YDATON_ARMODIA': 'Αρμόδια Διεύθυνση Υδάτων', 'YDROMETRO_ARITHMOS': 'YDROMETRO_ARITHMOS', 'HMER_KATAXWRHSHS': 'HMER_KATAXWRHSHS', 'YPEF_APOGRAFHS': 'YPEF_APOGRAFHS', 'ET_ENARKSIS_XRHSHS': 'ET_ENARKSIS_XRHSHS', 'ETHSIA_APOLHPS_POSOT_NEROU': 'ETHSIA_APOLHPS_POSOT_NEROU', 'AR_PRWT_SY': 'AR_PRWT_SY', 'HMER_PRWT_SY': 'HMER_PRWT_SY', 'EKD_ARXH_SY': 'EKD_ARXH_SY', 'YDAT_S': 'YDAT_S', 'YDAT_U': 'YDAT_U', 'CREATE_USER': 'CREATE_USER', 'UPDATE_USER': 'UPDATE_USER', 'NAT2000CODE': 'NAT2000CODE', 'GR_BW_NAME': 'GR_BW_NAME', 'GR_DW_CODE': 'GR_DW_CODE', 'GR_NZ_NAME': 'GR_NZ_NAME', 'YDAT_S_CHEM': 'YDAT_S_CHEM', 'YDAT_S_ECO': 'YDAT_S_ECO', 'YDAT_U_CHEM': 'YDAT_U_CHEM', 'YDAT_U_QUANT': 'YDAT_U_QUANT', 'YDAT_SYST_CHEM': 'YDAT_SYST_CHEM', 'YDAT_SYST_ECOQUANT': 'YDAT_SYST_ECOQUANT', 'ALLO_EID_METR': 'ALLO_EID_METR', 'DIASTASEIS_DIATRHSHS': 'DIASTASEIS_DIATRHSHS', 'YFALM_AREA': 'YFALM_AREA', });
lyr_diff_od_yp_nat_arx_spit_7.set('fieldAliases', {'fid': 'fid', 'id': 'id', 'wb_code': 'wb_code', 'wb_name_el': 'wb_name_el', 'quant_stat': 'quant_stat', 'chem_stat': 'chem_stat', 'rbd': 'rbd', 'area_ypogeiwn': 'area_ypogeiwn', });
lyr_spitia_points_8.set('fieldAliases', {'id': 'id', });
lyr_clip_ypogeia_ydatika_0.set('fieldImages', {'fid': 'TextEdit', 'id': 'Range', 'wb_code': 'TextEdit', 'wb_name_el': 'TextEdit', 'quant_stat': 'TextEdit', 'chem_stat': 'TextEdit', 'rbd': 'TextEdit', 'area_ypogeiwn': 'Range', });
lyr_area_of_interest_3.set('fieldImages', {'id': '', });
lyr_odiko2100_buffer50_4.set('fieldImages', {'fid': '', 'objectid': '', 'type': '', 'namegrk': '', 'nameeng': '', 'length': '', 'armodiot': '', 'arth_num': '', 'other_name': '', 'οΏ½οΏ½οΏ½': '', });
lyr_diff_odiko_ypogeia_natura_arxaiologikoi_5.set('fieldImages', {'fid': 'TextEdit', 'id': 'Range', 'wb_code': 'TextEdit', 'wb_name_el': 'TextEdit', 'quant_stat': 'TextEdit', 'chem_stat': 'TextEdit', 'rbd': 'TextEdit', 'area_ypogeiwn': 'Range', });
lyr_drills_in_area_of_interest_6.set('fieldImages', {'fid': 'TextEdit', 'OBJECTID': 'TextEdit', 'KWDIKOS_SY': 'TextEdit', 'X_EGSA87': 'TextEdit', 'Y_EGSA87': 'TextEdit', 'Z': 'TextEdit', 'IDIOKTHSIAKO_KATHESTWS': 'TextEdit', 'KATHESTWS_XRHSHS': 'TextEdit', 'EIDOS_SY': 'TextEdit', 'BATHOS_GEWTRHSHS': 'TextEdit', 'STATHMI_HREMIAS': 'TextEdit', 'DIAMETROS_DIATRHSHS': 'TextEdit', 'DIAMETROS_SWLHNWSHS': 'TextEdit', 'HLEKTRODOTHSH': 'TextEdit', 'AR_PAROXHS_DEH': 'TextEdit', 'PIEZOMETRO': 'TextEdit', 'YDROMETRO': 'TextEdit', 'YDROMETRO_ENDEIKSH': 'TextEdit', 'YDROMETRO_HMEROMHNIA': 'DateTime', 'ANTLIA': 'TextEdit', 'ANTLIA_TYPOS': 'TextEdit', 'ANTLIA_IPPODYNAMH': 'TextEdit', 'ANTLIA_BATHOS_TOPOTHETHSHS': 'TextEdit', 'AGWGOI_METAFORAS_NEROU': 'TextEdit', 'AGWGOI_METAFORAS_NEROU_ARITHMOS': 'TextEdit', 'AGWGOI_METAFORAS_NEROU_MHKOS': 'TextEdit', 'PERIFEREIA': 'TextEdit', 'PERIFEREIAKH_ENOTHTA': 'TextEdit', 'DHMOS_KALLIKRATH': 'TextEdit', 'DHMOTIKH_ENOTHTA': 'TextEdit', 'KOINOTHTA': 'TextEdit', 'TOPWNYMIO': 'TextEdit', 'YDATIKO_DIAMERISMA': 'TextEdit', 'LEKANH_APORROHS': 'TextEdit', 'YDATIKO_SYSTHMA': 'TextEdit', 'LITHOLOGIA': 'TextEdit', 'PARATHRHSEIS': 'TextEdit', 'KWDIKOS_IGME': 'TextEdit', 'KWDIKOS_EMSY': 'TextEdit', 'created_user': 'TextEdit', 'created_date': 'DateTime', 'last_edited_user': 'TextEdit', 'last_edited_date': 'DateTime', 'KWDIKOS_OPEKEPE': 'TextEdit', 'KWDIKOS_EDPYY': 'TextEdit', 'EIDOS_YDROFOROU': 'TextEdit', 'MESH_PAROXH': 'TextEdit', 'DIEYTHINSH_YDATWN': 'TextEdit', 'STATUS': 'TextEdit', 'IS_INSIDE': 'TextEdit', 'DNSI_YDATON_ARMODIA': 'TextEdit', 'YDROMETRO_ARITHMOS': 'TextEdit', 'HMER_KATAXWRHSHS': 'DateTime', 'YPEF_APOGRAFHS': 'TextEdit', 'ET_ENARKSIS_XRHSHS': 'Range', 'ETHSIA_APOLHPS_POSOT_NEROU': 'TextEdit', 'AR_PRWT_SY': 'TextEdit', 'HMER_PRWT_SY': 'DateTime', 'EKD_ARXH_SY': 'TextEdit', 'YDAT_S': 'TextEdit', 'YDAT_U': 'TextEdit', 'CREATE_USER': 'TextEdit', 'UPDATE_USER': 'TextEdit', 'NAT2000CODE': 'TextEdit', 'GR_BW_NAME': 'TextEdit', 'GR_DW_CODE': 'TextEdit', 'GR_NZ_NAME': 'TextEdit', 'YDAT_S_CHEM': 'TextEdit', 'YDAT_S_ECO': 'TextEdit', 'YDAT_U_CHEM': 'TextEdit', 'YDAT_U_QUANT': 'TextEdit', 'YDAT_SYST_CHEM': 'TextEdit', 'YDAT_SYST_ECOQUANT': 'TextEdit', 'ALLO_EID_METR': 'TextEdit', 'DIASTASEIS_DIATRHSHS': 'TextEdit', 'YFALM_AREA': 'TextEdit', });
lyr_diff_od_yp_nat_arx_spit_7.set('fieldImages', {'fid': 'TextEdit', 'id': 'Range', 'wb_code': 'TextEdit', 'wb_name_el': 'TextEdit', 'quant_stat': 'TextEdit', 'chem_stat': 'TextEdit', 'rbd': 'TextEdit', 'area_ypogeiwn': 'Range', });
lyr_spitia_points_8.set('fieldImages', {'id': 'TextEdit', });
lyr_clip_ypogeia_ydatika_0.set('fieldLabels', {'fid': 'no label', 'id': 'no label', 'wb_code': 'no label', 'wb_name_el': 'no label', 'quant_stat': 'no label', 'chem_stat': 'no label', 'rbd': 'no label', 'area_ypogeiwn': 'no label', });
lyr_area_of_interest_3.set('fieldLabels', {'id': 'no label', });
lyr_odiko2100_buffer50_4.set('fieldLabels', {'fid': 'no label', 'objectid': 'no label', 'type': 'no label', 'namegrk': 'no label', 'nameeng': 'no label', 'length': 'no label', 'armodiot': 'no label', 'arth_num': 'no label', 'other_name': 'no label', 'οΏ½οΏ½οΏ½': 'no label', });
lyr_diff_odiko_ypogeia_natura_arxaiologikoi_5.set('fieldLabels', {'fid': 'no label', 'id': 'no label', 'wb_code': 'no label', 'wb_name_el': 'no label', 'quant_stat': 'no label', 'chem_stat': 'no label', 'rbd': 'no label', 'area_ypogeiwn': 'no label', });
lyr_drills_in_area_of_interest_6.set('fieldLabels', {'fid': 'no label', 'OBJECTID': 'no label', 'KWDIKOS_SY': 'no label', 'X_EGSA87': 'no label', 'Y_EGSA87': 'no label', 'Z': 'no label', 'IDIOKTHSIAKO_KATHESTWS': 'no label', 'KATHESTWS_XRHSHS': 'no label', 'EIDOS_SY': 'no label', 'BATHOS_GEWTRHSHS': 'no label', 'STATHMI_HREMIAS': 'no label', 'DIAMETROS_DIATRHSHS': 'no label', 'DIAMETROS_SWLHNWSHS': 'no label', 'HLEKTRODOTHSH': 'no label', 'AR_PAROXHS_DEH': 'no label', 'PIEZOMETRO': 'no label', 'YDROMETRO': 'no label', 'YDROMETRO_ENDEIKSH': 'no label', 'YDROMETRO_HMEROMHNIA': 'no label', 'ANTLIA': 'no label', 'ANTLIA_TYPOS': 'no label', 'ANTLIA_IPPODYNAMH': 'no label', 'ANTLIA_BATHOS_TOPOTHETHSHS': 'no label', 'AGWGOI_METAFORAS_NEROU': 'no label', 'AGWGOI_METAFORAS_NEROU_ARITHMOS': 'no label', 'AGWGOI_METAFORAS_NEROU_MHKOS': 'no label', 'PERIFEREIA': 'no label', 'PERIFEREIAKH_ENOTHTA': 'no label', 'DHMOS_KALLIKRATH': 'no label', 'DHMOTIKH_ENOTHTA': 'no label', 'KOINOTHTA': 'no label', 'TOPWNYMIO': 'no label', 'YDATIKO_DIAMERISMA': 'no label', 'LEKANH_APORROHS': 'no label', 'YDATIKO_SYSTHMA': 'no label', 'LITHOLOGIA': 'no label', 'PARATHRHSEIS': 'no label', 'KWDIKOS_IGME': 'no label', 'KWDIKOS_EMSY': 'no label', 'created_user': 'no label', 'created_date': 'no label', 'last_edited_user': 'no label', 'last_edited_date': 'no label', 'KWDIKOS_OPEKEPE': 'no label', 'KWDIKOS_EDPYY': 'no label', 'EIDOS_YDROFOROU': 'no label', 'MESH_PAROXH': 'no label', 'DIEYTHINSH_YDATWN': 'no label', 'STATUS': 'no label', 'IS_INSIDE': 'no label', 'DNSI_YDATON_ARMODIA': 'no label', 'YDROMETRO_ARITHMOS': 'no label', 'HMER_KATAXWRHSHS': 'no label', 'YPEF_APOGRAFHS': 'no label', 'ET_ENARKSIS_XRHSHS': 'no label', 'ETHSIA_APOLHPS_POSOT_NEROU': 'no label', 'AR_PRWT_SY': 'no label', 'HMER_PRWT_SY': 'no label', 'EKD_ARXH_SY': 'no label', 'YDAT_S': 'no label', 'YDAT_U': 'no label', 'CREATE_USER': 'no label', 'UPDATE_USER': 'no label', 'NAT2000CODE': 'no label', 'GR_BW_NAME': 'no label', 'GR_DW_CODE': 'no label', 'GR_NZ_NAME': 'no label', 'YDAT_S_CHEM': 'no label', 'YDAT_S_ECO': 'no label', 'YDAT_U_CHEM': 'no label', 'YDAT_U_QUANT': 'no label', 'YDAT_SYST_CHEM': 'no label', 'YDAT_SYST_ECOQUANT': 'no label', 'ALLO_EID_METR': 'no label', 'DIASTASEIS_DIATRHSHS': 'no label', 'YFALM_AREA': 'no label', });
lyr_diff_od_yp_nat_arx_spit_7.set('fieldLabels', {'fid': 'no label', 'id': 'no label', 'wb_code': 'no label', 'wb_name_el': 'no label', 'quant_stat': 'no label', 'chem_stat': 'no label', 'rbd': 'no label', 'area_ypogeiwn': 'no label', });
lyr_spitia_points_8.set('fieldLabels', {'id': 'no label', });
lyr_spitia_points_8.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});